package com.android.aidscape;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class welcome extends AppCompatActivity {


    private Button wlogbtn, wsignupbtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);



        wlogbtn = findViewById(R.id.wlogbtn);
        wlogbtn.setOnClickListener(view -> {
            startActivity(new Intent(welcome.this, com.android.aidscape.Login.class));

        });

        wsignupbtn = findViewById(R.id.wsignupbtn);
        wsignupbtn.setOnClickListener(view -> {
            startActivity(new Intent(welcome.this, com.android.aidscape.Signup.class));

        });



    }
}