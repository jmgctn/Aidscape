package com.android.aidscape;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class injuries extends AppCompatActivity {


    Button acutebtn, chronicbtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_injuries);


        acutebtn = findViewById(R.id.acutebtn);

        acutebtn.setOnClickListener(view -> {
            startActivity(new Intent(injuries.this, acute.class));

        });


        chronicbtn = findViewById(R.id.chronicbtn);

        chronicbtn.setOnClickListener(view -> {
            startActivity(new Intent(injuries.this, chronic.class));
        });


    }
}