package com.android.aidscape;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;


public class PrepareFragment extends Fragment {

    ImageButton imgBtnTyphoon, imgBtnEarthquake, imgBtnFire, imgBtnLandslide;


@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_prepare, container, false);
        requireActivity().setTitle("Prepare");


        return  rootView;
    }


    @Override
    public void onViewCreated (@NonNull View view, @Nullable Bundle saveInstanceState) {

        imgBtnTyphoon = requireView().findViewById(R.id.imgBtnTyphoon);
        imgBtnTyphoon.setOnClickListener(v -> {
            Intent myIntent = new Intent(PrepareFragment.this.getActivity(),typhoon.class);
            PrepareFragment.this.startActivity(myIntent);
        });



        imgBtnEarthquake = requireView().findViewById(R.id.imgBtnEarthquake);
        imgBtnEarthquake.setOnClickListener(v -> {
            Intent myIntent = new Intent(PrepareFragment.this.getActivity(),earthquake.class);
            PrepareFragment.this.startActivity(myIntent);
        });


        imgBtnFire = requireView().findViewById(R.id. imgBtnFire);
        imgBtnFire.setOnClickListener(v -> {
            Intent myIntent = new Intent(PrepareFragment.this.getActivity(),fire.class);
            PrepareFragment.this.startActivity(myIntent);
        });


        imgBtnLandslide = requireView().findViewById(R.id.imgBtnLandslide);
        imgBtnLandslide.setOnClickListener(v -> {
            Intent myIntent = new Intent(PrepareFragment.this.getActivity(),landslide.class);
            PrepareFragment.this.startActivity(myIntent);
        });


    }
}