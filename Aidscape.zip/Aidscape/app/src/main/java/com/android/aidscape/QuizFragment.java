package com.android.aidscape;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;


public class QuizFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_quiz, container, false);
        requireActivity().setTitle("Quiz");

        MaterialCardView firstAidCard = view.findViewById(R.id.firstAidCard);
        MaterialCardView bandagingCard = view.findViewById(R.id.bandagingCard);
        MaterialCardView woundsCard = view.findViewById(R.id.woundsCard);
        MaterialCardView asthmaCard = view.findViewById(R.id.asthmaCard);
        MaterialCardView chokingCard = view.findViewById(R.id.chokingCard);
        MaterialCardView fracturesCard = view.findViewById(R.id.fracturesCard);
        MaterialCardView earthquakeCard = view.findViewById(R.id.earthquakeCard);
        MaterialCardView fireCard = view.findViewById(R.id.fireCard);
        MaterialCardView typhoonCard = view.findViewById(R.id.typhoonCard);


        firstAidCard.setOnClickListener(view1 -> startActivity(new Intent(requireContext(), FirstAidQuiz.class)));
        bandagingCard.setOnClickListener(view1 -> startActivity(new Intent(requireContext(), BandagingQuiz.class)));
        woundsCard.setOnClickListener(view1 -> startActivity(new Intent(requireContext(), WoundsQuiz.class)));
        asthmaCard.setOnClickListener(view1 -> startActivity(new Intent(requireContext(), AsthmaQuiz.class)));
        chokingCard.setOnClickListener(view1 -> startActivity(new Intent(requireContext(), ChokingQuiz.class)));
        fracturesCard.setOnClickListener(view1 -> startActivity(new Intent(requireContext(), FracturesQuiz.class)));
        earthquakeCard.setOnClickListener(view1 -> startActivity(new Intent(requireContext(), EarthquakeQuiz.class)));
        fireCard.setOnClickListener(view1 -> startActivity(new Intent(requireContext(), FireQuiz.class)));
        typhoonCard.setOnClickListener(view1 -> startActivity(new Intent(requireContext(), TyphoonQuiz.class)));


        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle saveInstanceState) {

        view.setFocusableInTouchMode(true);
        view.requestFocus();
        view.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                MaterialAlertDialogBuilder materialAlertDialogBuilder = new MaterialAlertDialogBuilder(requireContext());
                materialAlertDialogBuilder.setTitle(R.string.app_name);
                materialAlertDialogBuilder.setMessage("Are you sure want to exit the app?");
                materialAlertDialogBuilder.setNegativeButton(android.R.string.no, (dialogInterface, i) -> dialogInterface.dismiss());
                materialAlertDialogBuilder.setPositiveButton(android.R.string.yes, (dialogInterface, i) -> requireActivity().finish());
                materialAlertDialogBuilder.show();
                return true;
            }
            return false;
        });
    }
}
