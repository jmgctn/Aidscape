package com.android.aidscape;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class LearnFragment extends Fragment {


    ImageButton imgBtnBandaging, imgBtnInjuries, imgBtnFistAid, imgBtnWound, imgBtnFracture, imgBtnAsthma, imgBtnChoking;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_learn, container, false);
        requireActivity().setTitle("Learn");


        return  rootView;

    }


    @Override
    public void onViewCreated (@NonNull View view, @Nullable Bundle saveInstanceState) {

        imgBtnFistAid = requireView().findViewById(R.id.imgBtnFistAid);
        imgBtnFistAid.setOnClickListener(v -> {
            Intent myIntent = new Intent(LearnFragment.this.getActivity(),firstaid.class);
            LearnFragment.this.startActivity(myIntent);
        });


        imgBtnBandaging = requireView().findViewById(R.id.imgBtnBandaging);
        imgBtnBandaging.setOnClickListener(v -> {
            Intent myIntent = new Intent(LearnFragment.this.getActivity(),MainActivity.class);
            LearnFragment.this.startActivity(myIntent);
        });

        imgBtnInjuries = requireView().findViewById(R.id.imgBtnInjuries);
        imgBtnInjuries.setOnClickListener(v -> {
            Intent myIntent = new Intent(LearnFragment.this.getActivity(),injuries.class);
            LearnFragment.this.startActivity(myIntent);
        });


        imgBtnWound = requireView().findViewById(R.id. imgBtnWound);
        imgBtnWound.setOnClickListener(v -> {
            Intent myIntent = new Intent(LearnFragment.this.getActivity(),wound.class);
            LearnFragment.this.startActivity(myIntent);
        });


        imgBtnFracture = requireView().findViewById(R.id.imgBtnFracture);
        imgBtnFracture.setOnClickListener(v -> {
            Intent myIntent = new Intent(LearnFragment.this.getActivity(),fracture.class);
            LearnFragment.this.startActivity(myIntent);
        });


        imgBtnAsthma = requireView().findViewById(R.id.imgBtnAsthma);
        imgBtnAsthma.setOnClickListener(v -> {
            Intent myIntent = new Intent(LearnFragment.this.getActivity(),asthma.class);
            LearnFragment.this.startActivity(myIntent);
        });



        imgBtnChoking = requireView().findViewById(R.id.imgBtnChoking);
        imgBtnChoking.setOnClickListener(v -> {
            Intent myIntent = new Intent(LearnFragment.this.getActivity(),choking.class);
            LearnFragment.this.startActivity(myIntent);
        });







    }


}

