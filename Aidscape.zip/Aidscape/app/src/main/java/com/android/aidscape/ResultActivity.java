package com.android.aidscape;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    TextView correctT, wrongT, resultInfo, resultScore;
    ImageView resultImage;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        correctT = findViewById(R.id.correctScore);
        wrongT = findViewById(R.id.wrongScore);
        resultInfo = findViewById(R.id.resultInfo);
        resultScore = findViewById(R.id.resultScore);
        resultImage = findViewById(R.id.resultImage);

        int correct = getIntent().getIntExtra("correct", 0);
        int wrong = getIntent().getIntExtra("wrong", 0);
        int score = correct * 5;

        correctT.setText("" + correct);
        wrongT.setText("" + wrong);
        resultScore.setText("" + score);

        if (correct >= 0 && correct <= 2) {
            resultInfo.setText("You have to take the test again");
            resultImage.setImageResource(R.drawable.baseline_sentiment_very_dissatisfied_24);
        } else if (correct >= 3 && correct <= 4) {
            resultInfo.setText("You have to try a little more");
            resultImage.setImageResource(R.drawable.baseline_sentiment_satisfied_24);
        } else if (correct >= 5 && correct <= 6) {
            resultInfo.setText("You're Pretty Good");
            resultImage.setImageResource(R.drawable.baseline_sentiment_satisfied_alt_24);
        } else {
            resultInfo.setText("Congratulations");
            resultImage.setImageResource(R.drawable.baseline_sentiment_satisfied_alt_24);
        }
    }
}