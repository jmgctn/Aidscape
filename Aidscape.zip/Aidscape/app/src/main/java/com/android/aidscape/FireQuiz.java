package com.android.aidscape;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FireQuiz extends AppCompatActivity {

    TextView quiztest, aans, bans, cans, dans;
    List<QuestionItem> questionitem;
    int currentQuestions = 0;
    int correct= 0, wrong = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        quiztest = findViewById(R.id.quizTest);
        aans = findViewById(R.id.aAnswer);
        bans = findViewById(R.id.bAnswer);
        cans = findViewById(R.id.cAnswer);
        dans = findViewById(R.id.dAnswer);

        try {
            loadAllQuestions();
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        Collections.shuffle(questionitem);
        setQuestionScreen(currentQuestions);

        aans.setOnClickListener(view ->{
                if (questionitem.get(currentQuestions).getAns1().equals(questionitem.get(currentQuestions).getCorrect())){
                    correct++;
                    aans.setBackgroundResource(R.color.green);
                    aans.setTextColor(ContextCompat.getColor(FireQuiz.this, R.color.white));
                }else {
                    wrong++;
                    aans.setBackgroundResource(R.color.red);
                    aans.setTextColor(ContextCompat.getColor(FireQuiz.this, R.color.white));
                }

                if (currentQuestions < questionitem.size()-1){
                    Handler handler = new Handler();
                    handler.postDelayed(() -> {
                        currentQuestions++;
                        setQuestionScreen(currentQuestions);
                        aans.setBackgroundResource(R.color.white);
                        aans.setTextColor(ContextCompat.getColor(FireQuiz.this, R.color.text_secondary_color));
                    },500);
                }else {
                    Intent intent = new Intent(FireQuiz.this, ResultActivity.class);
                    intent.putExtra("correct", correct);
                    intent.putExtra("wrong", wrong);
                    startActivity(intent);
                    finish();
                }
            });

            bans.setOnClickListener(view ->{
                if (questionitem.get(currentQuestions).getAns2().equals(questionitem.get(currentQuestions).getCorrect())){
                    correct++;
                    bans.setBackgroundResource(R.color.green);
                    bans.setTextColor(ContextCompat.getColor(FireQuiz.this, R.color.white));
                }else {
                    wrong++;
                    bans.setBackgroundResource(R.color.red);
                    bans.setTextColor(ContextCompat.getColor(FireQuiz.this, R.color.white));
                }

                if (currentQuestions < questionitem.size()-1){
                    Handler handler = new Handler();
                    handler.postDelayed(() -> {
                        currentQuestions++;
                        setQuestionScreen(currentQuestions);
                        bans.setBackgroundResource(R.color.white);
                        bans.setTextColor(ContextCompat.getColor(FireQuiz.this, R.color.text_secondary_color));
                    },500);
                }else {
                    Intent intent = new Intent(FireQuiz.this, ResultActivity.class);
                    intent.putExtra("correct", correct);
                    intent.putExtra("wrong", wrong);
                    startActivity(intent);
                    finish();
                }
            });
            cans.setOnClickListener(view ->{
                if (questionitem.get(currentQuestions).getAns3().equals(questionitem.get(currentQuestions).getCorrect())){
                    correct++;
                    cans.setBackgroundResource(R.color.green);
                    cans.setTextColor(ContextCompat.getColor(FireQuiz.this, R.color.white));
                }else {
                    wrong++;
                    cans.setBackgroundResource(R.color.red);
                    cans.setTextColor(ContextCompat.getColor(FireQuiz.this, R.color.white));
                }

                if (currentQuestions < questionitem.size()-1){
                    Handler handler = new Handler();
                    handler.postDelayed(() -> {
                        currentQuestions++;
                        setQuestionScreen(currentQuestions);
                        cans.setBackgroundResource(R.color.white);
                        cans.setTextColor(ContextCompat.getColor(FireQuiz.this, R.color.text_secondary_color));
                    },500);
                }else {
                    Intent intent = new Intent(FireQuiz.this, ResultActivity.class);
                    intent.putExtra("correct", correct);
                    intent.putExtra("wrong", wrong);
                    startActivity(intent);
                    finish();
                }
            });

            dans.setOnClickListener(view ->{
                if (questionitem.get(currentQuestions).getAns4().equals(questionitem.get(currentQuestions).getCorrect())){
                    correct++;
                    dans.setBackgroundResource(R.color.green);
                    dans.setTextColor(ContextCompat.getColor(FireQuiz.this, R.color.white));
                }else {
                    wrong++;
                    dans.setBackgroundResource(R.color.red);
                    dans.setTextColor(ContextCompat.getColor(FireQuiz.this, R.color.white));
                }

                if (currentQuestions < questionitem.size()-1){
                    Handler handler = new Handler();
                    handler.postDelayed(() -> {
                        currentQuestions++;
                        setQuestionScreen(currentQuestions);
                        dans.setBackgroundResource(R.color.white);
                        dans.setTextColor(ContextCompat.getColor(FireQuiz.this, R.color.text_secondary_color));
                    },500);
                }else {
                    Intent intent = new Intent(FireQuiz.this, ResultActivity.class);
                    intent.putExtra("correct", correct);
                    intent.putExtra("wrong", wrong);
                    startActivity(intent);
                    finish();
                }
            });
        }



    private void setQuestionScreen(int currentQuestions) {
        quiztest.setText(questionitem.get(currentQuestions).getQuestion());
        aans.setText(questionitem.get(currentQuestions).getAns1());
        bans.setText(questionitem.get(currentQuestions).getAns2());
        cans.setText(questionitem.get(currentQuestions).getAns3());
        dans.setText(questionitem.get(currentQuestions).getAns4());

    }

    private void loadAllQuestions() throws JSONException {
        questionitem = new ArrayList<>();
        String jsonquiz = loadJsonFromAsset();
        try {
            JSONObject jsonObject = new JSONObject(jsonquiz);
            JSONArray questions = jsonObject.getJSONArray("fire");
            for (int i = 0; i < questions.length(); i++) {
                JSONObject question = questions.getJSONObject(i);

                String questionString = question.getString("question");
                String ans1String = question.getString("ans1");
                String ans2nString = question.getString("ans2");
                String ans3String = question.getString("ans3");
                String ans4String = question.getString("ans4");
                String correctString = question.getString("correct");

                questionitem.add(new QuestionItem(questionString, ans1String, ans2nString, ans3String, ans4String, correctString));
            }
        } catch (JSONException e){
            e.printStackTrace();
        }
    }

    private String loadJsonFromAsset() {
        String json = "";
        try {
            InputStream inputStream = getAssets().open("fire.json");
            int size = inputStream.available();
            byte[]buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();
            json = new String(buffer, StandardCharsets.UTF_8);
        } catch (IOException e){
            e.printStackTrace();
        }
        return json;
    }
}