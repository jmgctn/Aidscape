package com.android.aidscape;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import java.util.ArrayList;

public class Adapter extends PagerAdapter {

    private Context context;
    private ArrayList<Model> modelArrayList;

// constructor
    public Adapter(Context context, ArrayList<Model> modelArrayList) {
        this.context = context;
        this.modelArrayList = modelArrayList;
    }

    @Override
    public int getCount() {
        return modelArrayList.size(); // return size of item in list
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view.equals(object);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {

        //inflate layout card_item.xml
        View view = LayoutInflater.from(context).inflate(R.layout.card_item, container, false);

        // init uid views from card_item.xml
        ImageView cardone = view.findViewById(R.id.cardone);
        TextView dscrptone = view.findViewById(R.id.dscrptone);

// get data
    Model model = modelArrayList.get(position);
    String description = model.getDescription();
    int image = model.getImage();


    // set data
        cardone.setImageResource(image);
        dscrptone.setText(description);



// add view to container
        container.addView(view, position);


        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        super.destroyItem(container, position, object);
        container.removeView((View)object);
    }
}
