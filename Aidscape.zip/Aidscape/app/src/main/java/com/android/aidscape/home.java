package com.android.aidscape;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Button btngetstarted;

        btngetstarted = findViewById(R.id.btngetstarted);
        btngetstarted.setOnClickListener(view -> {
            startActivity(new Intent(home.this, welcome.class));

        });

    }
}