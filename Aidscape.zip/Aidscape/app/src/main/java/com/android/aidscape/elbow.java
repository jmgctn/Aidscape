package com.android.aidscape;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class elbow extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elbow);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}