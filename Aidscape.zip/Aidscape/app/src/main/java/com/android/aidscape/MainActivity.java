package com.android.aidscape;



import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {



    // action bar
    private ActionBar actionBar;

    private ViewPager ViewPagerMain;

    private ArrayList<Model> modelArrayList;

    private Adapter Adapter;



    private Button headorearbtn, eyebtn, handbtn, elbowbtn, armslingbtn, kneebtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // action bar
        actionBar = getSupportActionBar();

        // action bar
        ViewPagerMain = findViewById(R.id.viewPagerMain);
        loadCards();






        headorearbtn = findViewById(R.id.headorearbtn);
        headorearbtn.setOnClickListener(view -> {
            startActivity(new Intent(MainActivity.this, headorear.class));

        });



        eyebtn = findViewById(R.id.eyebtn);
        eyebtn.setOnClickListener(view -> {
            startActivity(new Intent(MainActivity.this, eye.class));

        });

        handbtn = findViewById(R.id.handbtn);
        handbtn.setOnClickListener(view -> {
            startActivity(new Intent(MainActivity.this, hand.class));

        });



        elbowbtn = findViewById(R.id.elbowbtn);
        elbowbtn.setOnClickListener(view -> {
            startActivity(new Intent(MainActivity.this, elbow.class));

        });

        armslingbtn = findViewById(R.id.armslingbtn);
        armslingbtn.setOnClickListener(view -> {
            startActivity(new Intent(MainActivity.this, armsling.class));

        });


        kneebtn = findViewById(R.id.kneebtn);
        kneebtn.setOnClickListener(view -> {
            startActivity(new Intent(MainActivity.this, knee.class));

        });



    }

    private void loadCards() {
        // init list
        modelArrayList =  new ArrayList<>();

        // add items to list
        modelArrayList.add(new Model(
                "Applying pressure to bleeding wounds",
                R.drawable.blood));
        modelArrayList.add(new Model("Covering wounds and burns",
                R.drawable.wound));
        modelArrayList.add(new Model("Providing support and immobilization for broken bones",
                R.drawable.support));

        //setup adapter
        Adapter = new Adapter(this,modelArrayList);
        // set adapter to view pager
        ViewPagerMain.setAdapter(Adapter);
        //set default padding from left/right
        ViewPagerMain.setPadding(100,0, 100,0 );


    }
}