package com.android.aidscape;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.android.aidscape.databinding.ActivityMenuBinding;



public class menu extends AppCompatActivity {


    ActivityMenuBinding binding;

@SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);


        binding = ActivityMenuBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        replaceFragment(new LearnFragment());


        binding.bottomnavigationview.setOnItemSelectedListener(item -> {


            switch (item.getItemId()) {


                case R.id.learn:
                    replaceFragment(new LearnFragment());
                    break;

                case R.id.prepare:
                    replaceFragment(new PrepareFragment());
                    break;
                case R.id.quiz:
                 replaceFragment(new QuizFragment());
                    break;

            }

            return true;
        });

    }


    private void replaceFragment(Fragment fragment) {


        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, fragment);
        fragmentTransaction.commitNow();



    }
}