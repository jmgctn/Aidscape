package com.android.aidscape;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Signup extends AppCompatActivity {

    EditText signupFirstName, signupLastName, signupEmail, signupPassword, signupConfirmPassword;
    Button signupButton;
    FirebaseDatabase database;
    DatabaseReference reference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);



        signupFirstName = findViewById(R.id.signupFirstName);
        signupLastName = findViewById(R.id.signupLastName);
        signupEmail = findViewById(R.id.signupEmail);
        signupPassword = findViewById(R.id.signupPassword);
        signupConfirmPassword = findViewById(R.id.signupConfirmPassword);
        signupButton = findViewById(R.id.signupButton);


        signupButton.setOnClickListener(view -> {
            database = FirebaseDatabase.getInstance();
            reference = database.getReference("users");


            String firstName = signupFirstName.getText().toString().trim();
            String lastName = signupLastName.getText().toString().trim();
            String email = signupEmail.getText().toString().trim();
            String password = signupPassword.getText().toString();
            String confirmPassword = signupConfirmPassword.getText().toString();




            if (!validateFirstName() | !validateLastName() | !validateEmail() | !validatePassword() | !validateConfirmPassword()) {
            } else {
                database = FirebaseDatabase.getInstance();
                reference = database.getReference("users");

                HelperClass helperClass = new HelperClass(firstName, lastName, email, password, confirmPassword);
                reference.child(firstName).setValue(helperClass);

                Toast.makeText(Signup.this, "You signed up successfully", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(Signup.this, Login.class);
                startActivity(intent);
            }
        });
    }
    public Boolean validateFirstName() {
        String val = signupFirstName.getText().toString();
        if (val.isEmpty()) {
            signupFirstName.setError("Email cannot be empty");
            return false;
        } else {
            signupFirstName.setError(null);
            return true;
        }
    }
    public Boolean validateLastName() {
        String val = signupLastName.getText().toString();
        if (val.isEmpty()) {
            signupLastName.setError("Email cannot be empty");
            return false;
        } else {
            signupLastName.setError(null);
            return true;
        }
    }
    public Boolean validateEmail() {
        String val = signupEmail.getText().toString();
        if (val.isEmpty()) {
            signupEmail.setError("Email cannot be empty");
            return false;
        } else {
            signupEmail.setError(null);
            return true;
        }
    }
    public Boolean validatePassword() {
        String val = signupPassword.getText().toString();
        if (val.isEmpty()) {
            signupPassword.setError("Email cannot be empty");
            return false;
        } else {
            signupPassword.setError(null);
            return true;
        }
    }
    public Boolean validateConfirmPassword() {
        String password = signupPassword.getText().toString();
        String confirmPassword = signupConfirmPassword.getText().toString();

        if (confirmPassword.isEmpty()) {
            signupConfirmPassword.setError("Confirm Password cannot be empty");
            return false;
        } else if (!confirmPassword.equals(password)) {
            signupConfirmPassword.setError("Passwords do not match");
            return false;
        } else {
            signupConfirmPassword.setError(null);
            return true;
        }
    }
        }
