package com.android.aidscape;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class armsling extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_armsling);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}